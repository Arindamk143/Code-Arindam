import turtle
from turtle import * 
import random
import time

screen = turtle.Screen()
screen.setup(700,600)
screen.bgcolor('black')
screen.title("Arindam")
speed(speed='fastest')

pen = turtle.Turtle()
pen.color("yellow")
  
# Defining a method to draw curve
def curve():
    for i in range(200):
  
        # Defining step by step curve motion
        pen.right(1)
        pen.forward(1)
  
# Defining method to draw a full heart
def heart():
  
    # Set the fill color to red
    pen.fillcolor('red')
  
    # Start filling the color
    pen.begin_fill()
  
    # Draw the left line
    pen.left(140)
    pen.forward(113)
  
    # Draw the left curve
    curve()
    pen.left(120)
  
    # Draw the right curve
    curve()
  
    # Draw the right line
    pen.forward(112)
  
    # Ending the filling of the color
    pen.end_fill()
  
# Defining method to write text
def txt():
  
    # Move turtle to air
    pen.up()
  
    # Move turtle to a given position
    pen.setpos(-68, 95)
  
    # Move the turtle to the ground
    pen.down()
  
    # Set the text color to lightgreen
    pen.color('Black')
  
    # Write the specified text in 
    # specified font style and size
    pen.write("Arindam Love Puja", font=(
      "Verdana", 12, "bold"))

  
# Draw a heart
heart()
  
# Write text
txt()
  
# To hide turtle
pen.ht()
time.sleep(5)

screen.clear()

screen = turtle.Screen()
screen.bgcolor('black')

speed(speed='fastest')

def draw(n, x, angle):
    # loop for number of stars
    for i in range(n):
          
        colormode(255)
          
        # choosing random integers 
        # between 0 and 255
        # to generate random rgb values 
        a = random.randint(0, 255)
        b = random.randint(0, 255)
        c = random.randint(0, 255)
          
        # setting the outline 
        # and fill colour
        pencolor(a, b, c)
        fillcolor(a, b, c)
          
        # begins filling the star
        begin_fill()
          
        # loop for drawing each star
        for j in range(5):
               
            forward(5 * n-5 * i)
            right(x)
            forward(5 * n-5 * i)
            right(72 - x)
              
        # colour filling complete
        end_fill()
          
        # rotating for
        # the next star
        rt(angle)
          
  
# setting the parameters
n = 30    # number of stars
x = 144   # exterior angle of each star
angle = 18    # angle of rotation for the spiral
  
draw(n, x, angle)

screen.clear()

screen = turtle.Screen()
screen.bgcolor('black')
speed(speed='fastest')

turtle.color('white')
style = ('Courier', 50, 'normal')
turtle.write('ARINDAM + PUJA', font=style, align='center')
turtle.hideturtle()

speed(speed='fastest')
colors = ['red', 'purple', 'blue', 'green', 'orange', 'yellow']
t = turtle.Pen()
turtle.bgcolor('black')
for x in range(360):
    speed(speed='fastest')
    t.pencolor(colors[x%6])
    t.width(x//100 + 1)
    t.forward(x)
    t.left(59)


turtle.reset()

turtle.color('yellow')
style = ('Arial', 50, 'bold')
turtle.write('I LOVE YOU PUJA', font=style, align='center')

turtle.done()