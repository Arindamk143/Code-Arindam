from tkinter import *

root = Tk()
root.geometry("400x650")
root.title("Arindam Calculator")
root.wm_iconbitmap("icon.ico")

def click(event):
    global calvar
    text = event.widget.cget("text")
    print(text)
    if text == "=":
        if calvar.get().isdigit():
            value = int(calvar.get())
        else:
            try:
                value = eval(calvar.get())

            except Exception as e:
                print(e)
                value = "Error"


        calvar.set(value)
        root.update()

    elif text == "C":
        calvar.set("")
        root.update()
    else:
        calvar.set(calvar.get()+ text)

# At First Passing A Entry with Variables
calvar = StringVar()
calvar.set("")

Entry(root,textvariable=calvar,font="Lucida 50 bold").pack(fill=X,ipady=5)

# Craeting Frame and pack Bottoms
f1 = Frame(root,bg="grey")
f1.pack()
B = Button(f1,text="9",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="8",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="7",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="6",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)

f1 = Frame(root,bg="grey")
f1.pack()
B = Button(f1,text="5",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="4",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="3",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="2",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)

f1 = Frame(root,bg="grey")
f1.pack()
B = Button(f1,text="1",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="0",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="C",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="=",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)

f1 = Frame(root,bg="grey")
f1.pack()
B = Button(f1,text="+",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="/",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="-",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)
B = Button(f1,text="*",font = "lucida 40 bold")
B.pack(side=LEFT,padx=15)
B.bind("<Button-1>",click)

root.mainloop()